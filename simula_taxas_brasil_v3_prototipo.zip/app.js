// Simula Taxas Brasil v3 - aceita BRL/USD, popup aviso > US$50, afiliados Shopee

const icmsRates = {
  "AC": 0.17, "AL": 0.18, "AP": 0.18, "AM": 0.18, "BA": 0.18, "CE": 0.18,
  "DF": 0.18, "ES": 0.17, "GO": 0.17, "MA": 0.18, "MT": 0.17, "MS": 0.17,
  "MG": 0.18, "PA": 0.18, "PB": 0.18, "PR": 0.18, "PE": 0.18, "PI": 0.18,
  "RJ": 0.20, "RN": 0.18, "RS": 0.18, "RO": 0.17, "RR": 0.18, "SC": 0.17,
  "SP": 0.18, "SE": 0.18, "TO": 0.18
};

// promotions with your Shopee affiliate links
const promotions = [
  {store:"Shopee", title:"Promoção 1", price_usd:0, img:"https://via.placeholder.com/400x260?text=Shopee+1", url:"https://s.shopee.com.br/3qERZiYxrv"},
  {store:"Shopee", title:"Promoção 2", price_usd:0, img:"https://via.placeholder.com/400x260?text=Shopee+2", url:"https://s.shopee.com.br/5VMfYq4w8H"},
  {store:"Shopee", title:"Promoção 3", price_usd:0, img:"https://via.placeholder.com/400x260?text=Shopee+3", url:"https://s.shopee.com.br/40XrmDP5DK"},
  {store:"Shopee", title:"Promoção 4", price_usd:0, img:"https://via.placeholder.com/400x260?text=Shopee+4", url:"https://s.shopee.com.br/1BDgP52yzt"}
];

async function fetchDollar(){
  try{
    const resp = await fetch('https://economia.awesomeapi.com.br/json/last/USD-BRL');
    const data = await resp.json();
    const rate = parseFloat(data['USDBRL'].bid);
    return rate;
  }catch(e){
    console.warn('Não foi possível obter cotação automática', e);
    return null;
  }
}

function formatBRL(v){ return v.toLocaleString('pt-BR',{style:'currency', currency:'BRL'}); }

function calculateFromUSD(totalUsd, cotacao, icmsRate){
  const usdThreshold = 50.00;
  let aliquota;
  let impostoImportacaoBRL = 0;
  const valorBRL = totalUsd * cotacao;

  if(totalUsd <= usdThreshold){
    aliquota = 0.20;
    impostoImportacaoBRL = valorBRL * aliquota;
  } else {
    aliquota = 0.60;
    const baseUsd = Math.max(0, totalUsd - 20.00);
    const baseBRL = baseUsd * cotacao;
    impostoImportacaoBRL = baseBRL * aliquota;
  }

  const icms = impostoImportacaoBRL * icmsRate;
  const total = valorBRL + impostoImportacaoBRL + icms;

  return {valorBRL, aliquota, impostoImportacaoBRL, icms, total};
}

document.addEventListener('DOMContentLoaded', async ()=> {
  const usdEl = document.getElementById('usd');
  const brlEl = document.getElementById('brl');
  const freteUsdEl = document.getElementById('frete_usd');
  const freteBrlEl = document.getElementById('frete_brl');
  const cotacaoEl = document.getElementById('cotacao');
  const estadoEl = document.getElementById('estado');
  const calcBtn = document.getElementById('calcular');
  const resetBtn = document.getElementById('reset');
  const refreshBtn = document.getElementById('refreshRate');
  const exportBtn = document.getElementById('exportPdf');
  const productCards = document.getElementById('productCards');
  const couponEl = document.getElementById('coupon');

  const modal = document.getElementById('modal');
  const modalText = document.getElementById('modalText');
  const modalClose = document.getElementById('modalClose');
  const modalOk = document.getElementById('modalOk');

  function populateStates(){
    const entries = Object.entries(icmsRates).sort();
    estadoEl.innerHTML = '';
    entries.forEach(([uf, rate])=>{
      const opt = document.createElement('option');
      opt.value = uf;
      opt.dataset.icms = rate;
      opt.textContent = uf + ' — ' + (rate*100).toFixed(0) + '%';
      if(uf==='SP') opt.selected = true;
      estadoEl.appendChild(opt);
    });
  }

  function renderPromotions(){
    productCards.innerHTML = '';
    promotions.forEach(p=>{
      const art = document.createElement('article');
      art.className = 'product';
      art.innerHTML = `
        <img src="${p.img}" alt="${p.title}">
        <h4>${p.title}</h4>
        <p class="muted">${p.store}</p>
        <div class="actionRow">
          <div class="price"><a href="${p.url}" target="_blank" rel="noopener">${p.url}</a></div>
          <div>
            <a class="btn" href="${p.url}" target="_blank" rel="noopener">Ver na Shopee</a>
          </div>
        </div>
      `;
      productCards.appendChild(art);
    });
  }

  async function updateRateToInput(){
    const rate = await fetchDollar();
    if(rate){
      cotacaoEl.value = rate.toFixed(4);
    } else {
      cotacaoEl.value = 5.65;
    }
  }

  populateStates();
  renderPromotions();
  await updateRateToInput();

  refreshBtn.addEventListener('click', async ()=> {
    refreshBtn.disabled = true;
    refreshBtn.textContent = 'Atualizando...';
    await updateRateToInput();
    refreshBtn.disabled = false;
    refreshBtn.textContent = 'Atualizar dólar';
  });

  function showModal(text){
    modalText.textContent = text;
    modal.setAttribute('aria-hidden', 'false');
  }
  function hideModal(){
    modal.setAttribute('aria-hidden', 'true');
  }
  modalClose.addEventListener('click', hideModal);
  modalOk.addEventListener('click', hideModal);

  calcBtn.addEventListener('click', ()=>{
    const cotacao = parseFloat(cotacaoEl.value) || 0;
    // determine totals: prefer USD fields; if empty, convert from BRL
    let usdValue = parseFloat(usdEl.value) || 0;
    let freteUsd = parseFloat(freteUsdEl.value) || 0;
    const brlValue = parseFloat(brlEl.value) || 0;
    const freteBrl = parseFloat(freteBrlEl.value) || 0;

    if((usdValue === 0) && (brlValue > 0)){
      if(cotacao <= 0){
        alert('Favor atualizar a cotação do dólar antes (ou informar manualmente).');
        return;
      }
      usdValue = brlValue / cotacao;
    }
    if((freteUsd === 0) && (freteBrl > 0)){
      if(cotacao <= 0){
        alert('Favor atualizar a cotação do dólar antes (ou informar manualmente).');
        return;
      }
      freteUsd = freteBrl / cotacao;
    }

    const totalUsd = usdValue + freteUsd;
    const icmsRate = parseFloat(estadoEl.selectedOptions[0].dataset.icms) || 0.18;

    // if exceeds 50 USD, show popup and apply 60% rule
    if(totalUsd > 50){
      showModal('⚠️ O valor informado ultrapassa US$ 50. Será aplicada a alíquota de 60% (com desconto de US$ 20 na base de cálculo), conforme regra vigente.');
    }

    const res = calculateFromUSD(totalUsd, cotacao, icmsRate);
    document.getElementById('valorBR').textContent = formatBRL(res.valorBRL);
    document.getElementById('valorUSD').textContent = totalUsd.toFixed(2) + ' US$';
    document.getElementById('aliquota').textContent = (res.aliquota*100).toFixed(0) + '%';
    document.getElementById('imposto').textContent = formatBRL(res.impostoImportacaoBRL);
    document.getElementById('icms').textContent = formatBRL(res.icms);
    document.getElementById('total').textContent = formatBRL(res.total);

    const cupom = couponEl.value.trim();
    const note = document.getElementById('couponNote');
    if(cupom) note.textContent = `Cupom "${cupom}" aplicado (informativo).`;
    else note.textContent = 'Cupom não altera impostos — é só informativo para o usuário.';
  });

  resetBtn.addEventListener('click', ()=>{
    usdEl.value = '';
    brlEl.value = '';
    freteUsdEl.value = '0';
    freteBrlEl.value = '0';
    couponEl.value = '';
    document.getElementById('valorBR').textContent = '-';
    document.getElementById('valorUSD').textContent = '-';
    document.getElementById('aliquota').textContent = '-';
    document.getElementById('imposto').textContent = '-';
    document.getElementById('icms').textContent = '-';
    document.getElementById('total').textContent = '-';
    updateRateToInput();
    hideModal();
  });

  exportBtn.addEventListener('click', ()=>{
    const element = document.getElementById('resultado');
    const opt = {
      margin:       0.3,
      filename:     'simulacao_taxas.pdf',
      image:        { type: 'jpeg', quality: 0.98 },
      html2canvas:  { scale: 2, useCORS: true },
      jsPDF:        { unit: 'in', format: 'a4', orientation: 'portrait' }
    };
    html2pdf().set(opt).from(element).save();
  });

});
